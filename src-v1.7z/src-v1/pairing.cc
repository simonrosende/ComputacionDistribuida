#include <base.hh>
#include <environment.hh>

#include "pairing.hh"

// Environment class to obtain the size of the environment
extern mrs::Environment env;

// TODO: Implement here your pairing-unpairing robot

// Constructor
PairingRobot::PairingRobot(unsigned int id, const mrs::Position2d & p, 
			   const mrs::RobotSettings & settings,
			   const mrs::Velocity2d & vel) :
  mrs::Robot(id, p, settings)
{
}

// Action (main) method
const mrs::Velocity2d &
PairingRobot::action(std::vector<mrs::RobotPtr> & neigh)
{
  
  return this->m_vel;
}

mrs::RobotPtr
PairingRobot::clone() const
{

}
