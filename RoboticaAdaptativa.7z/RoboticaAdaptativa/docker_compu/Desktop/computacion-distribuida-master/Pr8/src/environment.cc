/*
 * environment.hh (C) Inaki Rano 2022
 * 
 * Definition of environment class for the 2D multi-robot simulator
 * and the functions related to the environment: distance(), angle()
 * and wrap()
 *
 */
#include "environment.hh"

namespace mrs {

  // Pointer to the environment initilised to null until an
  // environment object is created
  Environment *Environment::m_envp = NULL;

  // Function to compute distances returns Euclidean distance if there
  // is no environment object created
  float distance(const Position2d & p0, const Position2d & p1)
  {
    if (Environment::m_envp == NULL)
      return (p0-p1).norm();
    
    return Environment::m_envp->dist(p0, p1);
  }

  // Function to compute angle, returns normal angle if there is no
  // environment object created
  float angle(const Position2d & p0, const Position2d & p1)
  {
    if (Environment::m_envp == NULL) {
      Position2d diff(p1 - p0);
      return atan2(diff[1], diff[0]);
    }
    
    return Environment::m_envp->ang(p0, p1);
  }
  // Wrap the point to fall again in the environment
  void wrap(Position2d & p)
  {
    if (Environment::m_envp == NULL)
      return;
    Environment::m_envp->wrap(p);
  }

  // Constructor sets the limit points, size and pointer to the
  // environment. Checks validity of the arguments and that there are
  // no more than one environment object
  Environment::Environment(const Position2d & min, const Position2d & max)
  {
    assert(m_envp == NULL);
    assert(min.size() == max.size());
    for (unsigned int ii = 0; ii < min.size(); ii++)
      assert(min[ii] < max[ii]);
    m_min = min;
    m_max = max;
    m_size = max - min;
    m_envp = this;
  }

  
  bool
  Environment::isFree(const Position2d & x, double r,
		      const SwarmPtr swarm) const
  {
    // If no swarm is passed as an argument in only checks that the
    // point is within the limits of the environment
    if (swarm == nullptr) {
      if ((x[0] > m_min[0]) && (x[0] <= m_max[0]) &&
	  (x[1] > m_min[1]) && (x[1] <= m_max[1]))
	return true;
      return false;
    }
    else
      for (std::vector<RobotPtr>::const_iterator iit = swarm->begin();
	     iit != swarm->end(); ++iit)
	  {
	    double lim(r + (*iit)->settings().radius);
	    if (dist(x, (*iit)->position()) < lim)
	      return false;
	  }
    
    return true;
  }

  Position2d
  Environment::random() const
  {
    return Position2d(0.5 * (m_min + m_max) +
		      Position2d::Random().cwiseProduct(0.5 * m_size));
  }

  Position2d
  Environment::random(float r, const SwarmPtr swarm, int & trials) const
  {
    Position2d p;
    bool isPFree(true);
    do {
      p = random();
      isPFree = isFree(p, r, swarm);
    } while ((trials-- > 0) &&(!isPFree));

    return p;
  }
  
  float
  Environment::dist(const Position2d & p0, const Position2d & p1) const
  {
    Position2d diff(p0 - p1);
    for (unsigned int ii = 0; ii < diff.size(); ii++)
      diff[ii] = wrapVar(diff[ii], m_size[ii]);

    return diff.norm();
  }

  float
  Environment::ang(const Position2d & p1, const Position2d & p0) const
  {
    Position2d diff(p0 - p1);
    for (unsigned int ii = 0; ii < diff.size(); ii++)
      diff[ii] = wrapVar(diff[ii], m_size[ii]);

    return atan2(diff[1], diff[0]);;
  }

  void
  Environment::wrap(Position2d & p) const
  {
    for (unsigned int ii = 0; ii < p.size(); ii++)
      p[ii] = wrapVar(p[ii], m_size[ii]);
  }
  
  std::ostream & operator<< (std::ostream & ofd, const mrs::Environment & env)
  {
    ofd << "Environment: " << "minP: " << env.min().transpose() << std::endl;
    ofd << "Environment: " << "maxP: " << env.max().transpose() << std::endl;
	 
    return ofd;
  }
  

}
