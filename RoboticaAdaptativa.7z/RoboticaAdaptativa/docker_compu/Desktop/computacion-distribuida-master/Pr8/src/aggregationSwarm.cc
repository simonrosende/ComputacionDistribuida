#include <iostream>
#include <stdlib.h>
#include <math.h>
#include <gtkmm.h>
#include <random>
#include <Eigen/Dense>
#include "robot.hh"
#include "swarm.hh"
#include "environment.hh"
#include "simulation.hh"
#include "simulation-plot.hh"

class AggregationRobot : public mrs::Robot {
public:
    std::mt19937 gen{std::random_device{}()};
    std::uniform_real_distribution<float> dis{0.0, 1.0};
    std::uniform_real_distribution<float> change_dir_prob{0.0, 1.0}; // Probabilidad de cambiar de dirección
    float stop_probability = 0.05; // Probabilidad de detenerse

    AggregationRobot(unsigned int id, const mrs::Position2d &p, 
        const mrs::RobotSettings &settings = mrs::defaultRobotSettings)
    : mrs::Robot(id, p, settings) {
        rndVel();  // Initialize velocity randomly
    }

    const mrs::Velocity2d &action(const std::vector<mrs::RobotPtr> &swarm) override {
        // Chequea si debe detenerse al encontrarse con otros robots
        for (const auto& other : swarm) {
            if (other.get() != this && (m_pos - other->position()).norm() < m_settings.rMax) {
                if (dis(gen) < stop_probability) {
                    m_vel = mrs::Velocity2d(0, 0); // Detener el robot
                    std::cout << "Robot " << m_id << " se detiene" << std::endl;
                    return m_vel;
                }
            }
        }

        // Decide si cambiar de dirección basado en la probabilidad
        if (change_dir_prob(gen) < 0.9) { // 10% de probabilidad de cambiar de dirección
            rndVel();
        }

        return m_vel;
    }

    void rndVel() {
        float angle = dis(gen) * 2 * M_PI;
        float speed = m_settings.vMax;
        m_vel = mrs::Velocity2d(cos(angle) * speed, sin(angle) * speed);
    }

    mrs::RobotPtr clone() const override {
        return std::make_shared<AggregationRobot>(m_id, m_pos, m_settings);
    }

    std::string name() const override {
        return "AggregationRobot";
    }
};

typedef std::shared_ptr<AggregationRobot> AggregationRobotPtr;
int main() {
    mrs::Environment env(mrs::Position2d(-5,-5), mrs::Position2d(5,5));
    mrs::RobotSettings rSettings = {0.15, 1.0, 0.0, 0.75, 0.0, 1.5, true, {1,0,0}};

    // Create an instance of Swarm
    mrs::Swarm swarmp;

    // Fill the Swarm with robots
    for (unsigned int i = 0; i < 20; ++i) {
        swarmp.push_back(std::make_shared<AggregationRobot>(i, mrs::Position2d::Random(), rSettings));
    }

    // Create a shared pointer for the Swarm to pass to Simulation
    mrs::SwarmPtr swarmpPtr = std::make_shared<mrs::Swarm>(swarmp);

    // Create a Simulation object using a shared pointer to Swarm
    mrs::SimulationPtr simp = std::make_shared<mrs::Simulation>(swarmpPtr);
    simp->run();

    Glib::RefPtr<Gtk::Application> app = Gtk::Application::create("es.usc.mrs");
    mrs::SimulationWindow dsp(simp, env);
    app->run(dsp);

    return 0;
}

