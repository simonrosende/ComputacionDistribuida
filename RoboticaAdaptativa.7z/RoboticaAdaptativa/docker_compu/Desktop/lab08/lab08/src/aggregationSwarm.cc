#include <iostream>
#include <stdlib.h>
#include <math.h>

#include <gtkmm.h>
#include <robot.hh>
#include <swarm.hh>
#include <environment.hh>
#include <simulation.hh>
#include <simulation-plot.hh>

class AggregationRobot : public mrs::Robot {
public:
  
  AggregationRobot(unsigned int id, const mrs::Position2d & p, 
	  const mrs::RobotSettings & settings = mrs::defaultRobotSettings,
	  const mrs::Velocity2d & vel = mrs::Velocity2d::Random()):
    mrs::Robot(id, p, settings)
  {
    //rndVel();
  }
  
// Método para definir la acción del robot, calculando su nueva velocidad.
const mrs::Velocity2d & action(const std::vector<mrs::RobotPtr> & swarm) override {
    int nearby_robots = 0;  // Inicializa el contador de robots cercanos.

    // Recorre cada robot en el enjambre para contar cuántos están dentro del rango rMax.
    for (const auto& other : swarm) {
        if (other.get() != this && (m_pos - other->position()).norm() < m_settings.rMax) {
            nearby_robots++;
        }
    }

    // Calcula un factor de reducción de velocidad basado en el número de robots cercanos.
    // Cuantos más robots cercanos, mayor será la reducción de la velocidad, aproximándose a cero.
    float speed_reduction_factor = std::max(0.0f, 1.0f - 0.6f * nearby_robots);

    // Genera una nueva dirección de manera aleatoria.
    float angle = static_cast<float>(rand()) / RAND_MAX * 2 * M_PI;
    float new_speed = m_settings.vMax * speed_reduction_factor;  // Aplica la reducción de velocidad.

    // Establece la nueva velocidad, ajustando la dirección y la magnitud de la misma.
    m_vel = mrs::Velocity2d(cos(angle) * new_speed, sin(angle) * new_speed);

    return m_vel;
}

  // Method to generate a random velocity
// No utilizamos la generación de velocidad aleatoria porque estamos ante un uniciclo,
// donde el control se basa en la velocidad lineal y la velocidad angular. En esta 
// implementacion definimos la velocidad angular como aleatoria, pero la velocidad lineal
// se calcula en función de la cantidad de robots cercanos.
  
//void rndVel() { m_vel = mrs::Velocity2d::Random(); }
  
  std::string name() const {return std::string("Agg");}

  mrs::RobotPtr clone() const override {
      return std::make_shared<AggregationRobot>(m_id, m_pos, m_settings, m_vel);
  }

};

// Definition of a pointer to an aggregation robot (unnecessary)
typedef std::shared_ptr<AggregationRobot> AggregationRobotPtr;

int
main()
{
  // Create an environment for the swarm
  mrs::Environment env(mrs::Position2d(-5,-5), mrs::Position2d(5,5));
  // TODO: You can change the settings of the robot to maximise
  // aggregation
  // Settings of the robots, different than the default settings
  mrs::RobotSettings rSettings = {0.15,     // Robot radius
				  1.0,      // Perceptual range
				  0.0,      // Min speed
				  0.75,     // Max speed
				  0.0,      // Min Omega
				  1.5,      // Max Omega
				  true,     // Visible
				  {1,0,0}}; // Colour
  // Create a robot which aggregates
  
  
  mrs::RobotPtr rp = std::make_shared<AggregationRobot>(0, mrs::Position2d(0,0), rSettings);

  
  // Create a random swarm of 20 robots
  const int numberOfRobots(10);
  //const int numberOfRobots(10);
  //const int numberOfRobots(50);
  // Initialise random number generator
  srand((unsigned int) time(0));
  // Create a random swarm of aggregating robots in the environment 
  mrs::SwarmPtr swarmp = mrs::Simulation::rndSwarm(numberOfRobots, rp, env);
  // Create a Simulation object to simulate the swarm
  mrs::SimulationPtr simp(std::make_shared<mrs::Simulation>(swarmp));

  // Run the simulation
  simp->run();

  Glib::RefPtr<Gtk::Application>  app = Gtk::Application::create("es.usc.mrs");
  mrs::SimulationWindow dsp(simp, env);
  app->run(dsp);
  
  return 0;
}
